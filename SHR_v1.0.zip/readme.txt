  _________                             ___ ___                __     __________       .__                    .___         .___
 /   _____/____   __ __   ___________  /   |   \_____    ____ |  | __ \______   \ ____ |  |   _________     __| _/____   __| _/
 \_____  \\__  \ |  |  \_/ __ \_  __ \/    ~    \__  \ _/ ___\|  |/ /  |       _// __ \|  |  /  _ \__  \   / __ |/ __ \ / __ | 
 /        \/ __ \|  |  /\  ___/|  | \/\    Y    // __ \\  \___|    <   |    |   \  ___/|  |_(  <_> ) __ \_/ /_/ \  ___// /_/ | 
/_______  (____  /____/  \___  >__|    \___|_  /(____  /\___  >__|_ \  |____|_  /\___  >____/\____(____  /\____ |\___  >____ | 
        \/     \/            \/              \/      \/     \/     \/         \/     \/                \/      \/    \/     \/ 


Created by pombenenge/crackman2

Release: v1.0

https://github.com/crackman2/SauerHack/tree/master/SauerHackReloaded



{ ---------- How to make the triggerbot work ----------	}
{ -> the aimbot autotriggers by checking the color    	}
{    of the pixel in the middle of the screen.        	}
{    if the color is equal to 0x00FF02 it triggers    	}
{							}
{ -> to make the enemies this color do the following  	}
{    1. replace green.jpg and red.jpg in	      	}
{       packages\models\ogro2 with the ones provided  	}
{       (!!Backup originals)			      	}
{    2. change your playmodel to orgo		      	}
{ -> 3. change the in-game settings to:			}
{	GAME:						}
{		-fullbright playermodels (max)		}
{		-force matching playermodels		}
{		-enable hide dead players		}
{	GFX:						}
{		-disable shaders, shadowmaps		}
{		-disable dynamic lights			}
{		-disable lighting, reflection, glow	}
{		 for models				}
{ -----------------------------------------------------	}


{ ---------------------- Controls ---------------------	}
{ -> right click to aim					}
{ -> 'V' to noclip (Controls are WASD, LSHIFT, LCTRL	}
{ -> 'X' to teleport everyone (enemies) to you (just 	}
{    stand there with a chainsaw and kill them all)	}
{ -> 'P' to autocapture (in ctf modes)			}
{ ----------------------------------------------------- }


Hints:
	- use the menu to enable and disable hotkeys 
	- lockaim is very useful for instagib
	- in general SauerHack Reloaded is useful for
	  instagib
	- i'm very sorry for the tacky titleart in 
	  this readme
